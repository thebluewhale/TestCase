"""Standalone IP evidence benchmark; never changes production or assigns risk levels."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

import requests
from PIL import Image

VIDEOS = [
    'Galaxy_WithUplus.mp4', 'GalaxyZFold7_KpopDemonHunters.mp4',
    'Pepsi_ExtraFeez.mp4', 'Pepsi_Pepzera.mp4',
    'Samsung_SpidermanLong.mp4', 'Samsung_SpidermanShorts.mp4',
]
HERE = Path(__file__).resolve().parent
SERVICE = HERE.parent.parent
FEATURES = [{'type': name, 'maxResults': 100, 'model': 'builtin/stable'}
            for name in ['LOGO_DETECTION', 'WEB_DETECTION']]
ENDPOINT = 'https://vision.googleapis.com/v1/images:annotate'


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def prepare(out, video_dir=None, filenames=None):
    video_dir = (video_dir or SERVICE / 'benchmarks/videos').resolve()
    filenames = VIDEOS if filenames is None else filenames
    if not filenames or len(set(filenames)) != len(filenames):
        raise ValueError('Input videos must be nonempty and unique')
    for filename in filenames:
        if Path(filename).name != filename or not (video_dir / filename).is_file():
            raise ValueError(f'Invalid or missing input video: {filename}')
    manifest = {
        'category_name': 'IP 침해 가능성', 'experimental_category_id': 22,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'endpoint': ENDPOINT, 'features': FEATURES,
        'sampling': 'First decoded frame in each occupied 1-second bin, relative to first video PTS; no resizing; JPEG q=2.',
        'timestamp_note': 'source_timestamp_seconds is actual selected frame PTS after rebasing; sample_second is its integer second bin. Audio duration does not add frames.',
        'risk_level': None,
        'limitations': ['Evidence only; no infringement/permission decision or calibrated risk level.',
                       'Web results are not an exhaustive search or proof of source ownership.',
                       'No score threshold, duplicate-frame suppression, or result filtering.',
                       'maxResults=100 is requested, not a guarantee of 100 results.',
                       'Only video frames; no audio/music analysis.'],
        'videos': [], 'source_directory': str(video_dir),
    }
    for filename in filenames:
        source = video_dir / filename
        folder = out / source.stem
        folder.mkdir()
        frames_dir = folder / 'frames'
        frames_dir.mkdir()
        probe = json.loads(subprocess.check_output([
            'ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(source)
        ], text=True))
        dump(folder / 'probe.json', probe)
        vf = "setpts=PTS-STARTPTS,select='isnan(prev_selected_t)+gt(floor(t),floor(prev_selected_t))',showinfo"
        command = ['ffmpeg', '-hide_banner', '-i', str(source), '-map', '0:v:0',
                   '-vf', vf, '-fps_mode', 'vfr', '-q:v', '2', '-threads', '2',
                   str(frames_dir / 'frame_%04d.jpg')]
        process = subprocess.run(command, capture_output=True, text=True, timeout=300)
        (folder / 'extraction.log').write_text(process.stderr)
        process.check_returncode()
        selected = re.findall(r'\bn:\s*\d+\s+pts:\s*\d+\s+pts_time:([\d.]+)', process.stderr)
        files = sorted(frames_dir.glob('*.jpg'))
        assert files and len(files) == len(selected), (filename, len(files), len(selected))
        frames = []
        for i, (path, timestamp) in enumerate(zip(files, selected, strict=True)):
            seconds = float(timestamp)
            with Image.open(path) as im:
                width, height = im.size
            frames.append({'frame_id': f'frame_{i+1:04d}',
                           'source_timestamp_seconds': seconds, 'sample_second': int(seconds),
                           'timestamp': f'{int(seconds)//60:02d}:{seconds%60:06.3f}',
                           'image': str(path.relative_to(out)), 'sha256': digest(path),
                           'width': width, 'height': height, 'bytes': path.stat().st_size})
        assert len({f['sample_second'] for f in frames}) == len(frames)
        video = {'filename': filename, 'stem': source.stem, 'source_sha256': digest(source),
                 'duration_seconds': float(probe['format']['duration']), 'frames': frames}
        manifest['videos'].append(video)
        dump(folder / 'frames.json', frames)
        print(f'EXTRACTED {filename}: {len(frames)} frames', flush=True)
    dump(out / 'manifest.json', manifest)
    return manifest


def make_batches(manifest, out):
    batches = []
    for video in manifest['videos']:
        current = []
        size = 0
        number = 1
        for frame in video['frames']:
            encoded = base64.b64encode((out / frame['image']).read_bytes()).decode('ascii')
            item = {'image': {'content': encoded}, 'features': FEATURES}
            item_size = len(json.dumps(item)) + 2
            if current and (len(current) >= 8 or size + item_size > 9_000_000):
                batches.append((video, number, current))
                current, size, number = [], 0, number + 1
            assert item_size < 9_000_000
            current.append((frame, item))
            size += item_size
        if current:
            batches.append((video, number, current))
    return batches


def call_batch(batch, out, token, project):
    video, number, items = batch
    folder = out / video['stem'] / 'batches'
    folder.mkdir(exist_ok=True)
    prefix = folder / f'batch_{number:03d}'
    response_path = prefix.with_suffix('.response.json')
    request_path = prefix.with_suffix('.request.json')
    status_path = prefix.with_suffix('.status.json')
    if status_path.exists():
        return json.loads(status_path.read_text())
    if request_path.exists():
        raise RuntimeError(f'Incomplete previous request, will not automatically resubmit: {prefix}')
    # Reconstruct exact wire payload from listed JPEGs and shared feature config;
    # do not duplicate base64 or persist authentication credentials.
    dump(request_path, {'endpoint': ENDPOINT, 'project': project, 'features': FEATURES,
                        'frames': items and [f for f, _ in items],
                        'started_at': datetime.now(timezone.utc).isoformat()})
    start = time.monotonic()
    status = {'video': video['filename'], 'batch': number, 'frames': len(items)}
    try:
        response = requests.post(ENDPOINT, headers={'Authorization': 'Bearer ' + token,
                                 'x-goog-user-project': project},
                                 json={'requests': [item for _, item in items]}, timeout=(30, 180))
        response_path.write_bytes(response.content)  # exact unmodified response body
        status['http_status'] = response.status_code
        body = response.json()
        entries = body.get('responses', [])
        if response.status_code != 200 or len(entries) != len(items):
            status['error'] = body.get('error', {'message': 'Response count mismatch'})
        else:
            results_dir = out / video['stem'] / 'responses'
            results_dir.mkdir(exist_ok=True)
            for (frame, _), result in zip(items, entries, strict=True):
                dump(results_dir / (frame['frame_id'] + '.json'), result)
            status['frame_errors'] = sum('error' in entry for entry in entries)
    except Exception as exc:
        # Never print HTTP exception URLs/headers that might contain credentials.
        status['error'] = {'type': type(exc).__name__, 'message': 'Request or response handling failed'}
    status['elapsed_seconds'] = round(time.monotonic() - start, 3)
    dump(status_path, status)
    print(json.dumps(status), flush=True)
    return status


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--project', default='dev-comfyui')
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--video-dir', type=Path, default=SERVICE / 'benchmarks/videos',
                        help='분석할 영상 디렉토리 (기본: 기존 벤치마크 videos)')
    parser.add_argument('--videos', nargs='+', help='명시적으로 선택한 영상 파일명 목록')
    parser.add_argument('--allow-network', action='store_true',
                        help='사용자 확인 후 실제 Cloud Vision 호출을 허용')
    parser.add_argument('--prepare-only', action='store_true',
                        help='프레임·manifest만 준비하고 인증/API 호출 없이 종료')
    args = parser.parse_args()
    if not args.allow_network and not args.prepare_only:
        parser.error('실제 API 호출에는 --allow-network가 필요합니다. 오프라인 준비는 --prepare-only.')
    if args.workers < 1:
        parser.error('--workers는 1 이상이어야 합니다.')
    args.out.mkdir(parents=True, exist_ok=True)
    path = args.out / 'manifest.json'
    if path.exists():
        manifest = json.loads(path.read_text())
        assert manifest['features'] == FEATURES
        if args.videos is not None:
            assert args.videos == [v['filename'] for v in manifest['videos']]
        assert manifest.get('project', args.project) == args.project
        for video in manifest['videos']:
            assert digest(args.video_dir / video['filename']) == video['source_sha256']
            for frame in video['frames']:
                assert digest(args.out / frame['image']) == frame['sha256']
    else:
        manifest = prepare(args.out, args.video_dir, args.videos)
        manifest['project'] = args.project
        manifest['ffmpeg_version'] = subprocess.check_output(['ffmpeg', '-version'], text=True).splitlines()[0]
        dump(path, manifest)
    if args.prepare_only:
        print(f'Prepared {sum(len(v["frames"]) for v in manifest["videos"])} frames; no API calls.')
        return
    token = subprocess.check_output(['gcloud', 'auth', 'print-access-token'], text=True, timeout=60).strip()
    batches = make_batches(manifest, args.out)
    print(f'REQUESTS {len(batches)} batches / {sum(len(v["frames"]) for v in manifest["videos"])} images / 2 features', flush=True)
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(call_batch, batch, args.out, token, args.project) for batch in batches]
        statuses = [f.result() for f in as_completed(futures)]
    dump(args.out / 'execution.json', {'batches': statuses, 'finished_at': datetime.now(timezone.utc).isoformat(),
                                     'success': all(not s.get('error') and not s.get('frame_errors') for s in statuses)})
    if any(s.get('error') or s.get('frame_errors') for s in statuses):
        raise SystemExit('Some requests failed; retained errors without relabeling as no detection.')


if __name__ == '__main__':
    main()
