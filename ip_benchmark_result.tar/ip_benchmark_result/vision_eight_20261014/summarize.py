"""Build complete offline evidence viewer and CSVs from saved Vision responses."""
import argparse
from collections import defaultdict
import csv
import html
import json
from pathlib import Path
from urllib.parse import urlparse

WEB_LISTS = ['fullMatchingImages', 'partialMatchingImages', 'pagesWithMatchingImages',
             'visuallySimilarImages']


def esc(value):
    return html.escape(str(value), quote=True)


def link(url, label=None):
    if urlparse(url).scheme not in ('http', 'https'):
        return esc(url)
    return f'<a href="{esc(url)}" target="_blank" rel="noopener noreferrer">{esc(label or url)}</a>'


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def write_csv(path, rows, fields):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                         for k, v in row.items()} for row in rows)


def table(headers, rows):
    return '<table><thead><tr>' + ''.join(f'<th>{esc(h)}</th>' for h in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join(f'<td>{v}</td>' for v in row) + '</tr>' for row in rows) + '</tbody></table>'


def main(out):
    manifest = json.loads((out / 'manifest.json').read_text())
    summaries, all_frame_rows, logos_csv, entities_csv, matches_csv = [], [], [], [], []
    sections = []
    for video in manifest['videos']:
        counts = defaultdict(int)
        logos, entities = {}, {}
        unique_urls = {k: set() for k in WEB_LISTS}
        details = []
        for frame in video['frames']:
            raw_path = Path(video['stem']) / 'responses' / (frame['frame_id'] + '.json')
            assert (out / raw_path).exists(), raw_path
            raw = json.loads((out / raw_path).read_text())
            assert 'error' not in raw, raw
            counts['successful_frames'] += 1
            web = raw.get('webDetection', {})
            annotations = raw.get('logoAnnotations', [])
            counts['logo_frames'] += bool(annotations)
            counts['logo_detections'] += len(annotations)
            counts['web_entity_frames'] += bool(web.get('webEntities'))
            common = {'video': video['filename'], 'frame_id': frame['frame_id'], 'timestamp': frame['timestamp'],
                      'source_timestamp_seconds': frame['source_timestamp_seconds']}
            row = {**common, 'image': frame['image'], 'raw_response': str(raw_path),
                   'logo_count': len(annotations), 'logos': [x.get('description') for x in annotations],
                   'web_entities': web.get('webEntities', []), 'best_guess_labels': web.get('bestGuessLabels', [])}
            for entry in annotations:
                name = entry.get('description', entry.get('mid', 'unknown'))
                agg = logos.setdefault(name, {'name': name, 'max_score': 0, 'frames': {}, 'detections': 0})
                agg['frames'][frame['frame_id']] = frame['timestamp']
                agg['max_score'] = max(agg['max_score'], entry.get('score', 0))
                agg['detections'] += 1
                logos_csv.append({**common, 'name': name, 'score': entry.get('score'),
                                  'mid': entry.get('mid'), 'bounding_poly': entry.get('boundingPoly'),
                                  'annotation': entry})
            for entry in web.get('webEntities', []):
                name = entry.get('description') or entry.get('entityId', 'unknown')
                key = (entry.get('entityId'), name)
                agg = entities.setdefault(key, {'name': name, 'entity_id': entry.get('entityId'),
                                               'max_score': 0, 'frames': {}})
                agg['frames'][frame['frame_id']] = frame['timestamp']
                agg['max_score'] = max(agg['max_score'], entry.get('score', 0))
                entities_csv.append({**common, 'name': name, 'entity_id': entry.get('entityId'),
                                     'score': entry.get('score'), 'annotation': entry})
            for kind in WEB_LISTS:
                entries = web.get(kind, [])
                counts[kind + '_frames'] += bool(entries)
                counts[kind + '_results'] += len(entries)
                row[kind + '_count'] = len(entries)
                for entry in entries:
                    url = entry.get('url', '')
                    if url:
                        unique_urls[kind].add(url)
                    matches_csv.append({**common, 'kind': kind, 'url': url,
                                        'page_title': entry.get('pageTitle', ''),
                                        'score': entry.get('score'), 'annotation': entry})
            all_frame_rows.append(row)
            logos_html = table(['로고', '탐지 점수', '좌표·전체 필드'], [
                [esc(x.get('description', '')), esc(x.get('score', '')),
                 '<pre>' + esc(json.dumps(x, ensure_ascii=False, indent=2)) + '</pre>'] for x in annotations]) if annotations else '<p>로고 결과 없음</p>'
            entities_html = table(['엔티티', '관련성 점수', 'ID'], [
                [esc(x.get('description', '')), esc(x.get('score', '')), esc(x.get('entityId', ''))]
                for x in web.get('webEntities', [])])
            web_html = []
            for kind in WEB_LISTS:
                lines = []
                for x in web.get(kind, []):
                    text = link(x.get('url', ''), x.get('pageTitle') or x.get('url', ''))
                    if x.get('pageTitle'):
                        text += '<br><small>' + esc(x.get('url', '')) + '</small>'
                    if 'score' in x:
                        text += ' · score=' + esc(x['score'])
                    for nested in ('fullMatchingImages', 'partialMatchingImages'):
                        for image in x.get(nested, []):
                            text += '<br>' + esc(nested) + ': ' + link(image.get('url', ''))
                    lines.append('<li>' + text + '</li>')
                web_html.append(f'<details><summary>{kind} ({len(lines)})</summary><ol>{"".join(lines)}</ol></details>')
            svg = []
            for logo in annotations:
                vertices = logo.get('boundingPoly', {}).get('vertices', [])
                if vertices:
                    pts = ' '.join(f'{v.get("x", 0)},{v.get("y", 0)}' for v in vertices)
                    svg.append(f'<polygon points="{pts}" fill="none" stroke="#ff3737" stroke-width="5"/>')
            preview = f'<div class="preview"><img loading="lazy" src="{esc(frame["image"])}" alt="{esc(frame["timestamp"])}"><svg viewBox="0 0 {frame["width"]} {frame["height"]}">{"".join(svg)}</svg></div>'
            details.append(f'<details class="frame"><summary>{esc(frame["timestamp"])} · 로고 {len(annotations)} · 엔티티 {len(web.get("webEntities", []))} · 일치 페이지 {len(web.get("pagesWithMatchingImages", []))}</summary>'
                           f'<p><a href="{esc(frame["image"])}">원본 프레임</a> · <a href="{esc(raw_path)}">전체 응답 JSON</a> · {frame["width"]}×{frame["height"]}</p>'
                           + preview + '<h4>Logo Detection</h4>' + logos_html + '<h4>Web Detection</h4>'
                           + '<p>bestGuessLabels: ' + esc(json.dumps(web.get('bestGuessLabels', []), ensure_ascii=False)) + '</p>'
                           + entities_html + ''.join(web_html)
                           + '<details><summary>반환된 모든 필드 펼치기</summary><pre>'
                           + esc(json.dumps(raw, ensure_ascii=False, indent=2)) + '</pre></details></details>')
        logo_list = sorted(logos.values(), key=lambda a: (-len(a['frames']), -a['max_score']))
        entity_list = sorted(entities.values(), key=lambda a: (-len(a['frames']), -a['max_score']))
        summary = {'filename': video['filename'], 'duration_seconds': video['duration_seconds'],
                   'sampled_frames': len(video['frames']), **dict(counts),
                   'unique_urls': {k: len(v) for k, v in unique_urls.items()},
                   'logos': logo_list, 'web_entities': entity_list, 'risk_level': None}
        summaries.append(summary)
        dump(out / video['stem'] / 'summary.json', summary)
        logo_table = table(['검출 로고', '프레임 수', '최고 탐지 점수', '등장 표본 시각'], [
            [esc(v['name']), str(len(v['frames'])), str(v['max_score']), esc(', '.join(v['frames'].values()))] for v in logo_list])
        entity_table = table(['웹 엔티티', '프레임 수', '최고 관련성 점수', '등장 표본 시각'], [
            [esc(v['name']), str(len(v['frames'])), str(v['max_score']), esc(', '.join(v['frames'].values()))] for v in entity_list])
        sections.append(f'<section id="{esc(video["stem"])}"><h2>{esc(video["filename"])}</h2>'
                        f'<p>{video["duration_seconds"]:.3f}초 · 표본 {len(video["frames"])}장 · 로고 검출 {counts["logo_frames"]}장</p>'
                        '<h3>모든 로고 집계</h3>' + logo_table
                        + '<details><summary>모든 웹 엔티티 집계</summary>' + entity_table + '</details>'
                        + '<h3>프레임별 전체 결과</h3>' + ''.join(details) + '</section>')
    summary_doc = {'category_name': 'IP 침해 가능성', 'total_frames': len(all_frame_rows),
                   'feature_units': len(all_frame_rows) * 2, 'videos': summaries}
    dump(out / 'summary.json', summary_doc)
    write_csv(out / 'frames.csv', all_frame_rows, list(all_frame_rows[0]))
    write_csv(out / 'logos.csv', logos_csv, ['video', 'frame_id', 'timestamp', 'source_timestamp_seconds', 'name', 'score', 'mid', 'bounding_poly', 'annotation'])
    write_csv(out / 'web_entities.csv', entities_csv, ['video', 'frame_id', 'timestamp', 'source_timestamp_seconds', 'name', 'entity_id', 'score', 'annotation'])
    write_csv(out / 'web_matches.csv', matches_csv, ['video', 'frame_id', 'timestamp', 'source_timestamp_seconds', 'kind', 'url', 'page_title', 'score', 'annotation'])
    findings = out / 'observations.html'
    observations = findings.read_text() if findings.exists() else ''
    overview = table(['영상', '표본', '로고 검출 프레임', '전체 일치 프레임', '부분 일치 프레임', '일치 페이지 프레임', '유사 이미지 프레임'], [
        [f'<a href="#{esc(Path(s["filename"]).stem)}">{esc(s["filename"])}</a>', str(s['sampled_frames']),
         str(s['logo_frames']), *[str(s[k + '_frames']) for k in WEB_LISTS]] for s in summaries])
    page = '''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>IP 침해 가능성 — Vision API 벤치마크</title>
<style>body{font:15px/1.65 system-ui,sans-serif;color:#243247;background:#f4f7fb;max-width:1250px;margin:30px auto;padding:0 20px}h1,h2,h3{color:#102344}section,.intro{background:white;padding:24px;margin:25px 0;border-radius:12px}table{border-collapse:collapse;width:100%;font-size:13px;margin:15px 0}td,th{border:1px solid #d6dfeb;padding:8px;vertical-align:top;text-align:left;overflow-wrap:anywhere}th{background:#eaf0f8}summary{cursor:pointer;font-weight:600;padding:10px}.frame{border:1px solid #ccd7e7;border-radius:8px;margin:12px 0;padding:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;background:#f4f7fb;padding:10px;max-height:550px;overflow:auto}a{color:#165ac0}li{margin:8px 0;overflow-wrap:anywhere}.preview{position:relative;width:fit-content;max-width:100%}.preview img{display:block;max-height:380px;max-width:100%;width:auto}.preview svg{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}small{color:#586c88}</style>
<h1>IP 침해 가능성</h1><div class="intro"><p>Google Cloud Vision LOGO_DETECTION + WEB_DETECTION · 6개 영상 · 초당 1장 표본</p>
<p>원본 해상도 JPEG, maxResults=100 요청, builtin/stable. 필터링 없이 모든 반환값을 보존했습니다. 영상의 각 1초 구간에서 첫 프레임을 추출하며 표시 시각은 실제 선택 프레임의 영상 PTS 기준입니다. 소수점 길이의 마지막 구간도 프레임이 있으면 포함합니다.</p>
<p><strong>등급 미판정:</strong> 로고·웹 일치는 침해 확정이나 사용 허가 여부를 뜻하지 않습니다. Web Entity 점수는 관련성 점수이며 침해 확률이 아닙니다. 웹 검색 결과가 없다고 권리 문제가 없다고 보장하지 않습니다. 라이선스·인물·음악 검증과 전체 프레임 분석은 수행하지 않았습니다.</p>
<p>외부 페이지 제목·URL은 API 응답이며 신뢰성이나 권리자를 검증하지 않았습니다. 외부 이미지는 자동으로 로드하지 않습니다. 로컬 프레임 위의 빨간 박스는 Logo Detection의 좌표입니다.</p>
<p><a href="frames.csv">프레임 CSV</a> · <a href="logos.csv">로고 전체 CSV</a> · <a href="web_entities.csv">웹 엔티티 전체 CSV</a> · <a href="web_matches.csv">웹 일치 전체 CSV</a> · <a href="summary.json">요약 JSON</a> · <a href="manifest.json">실행 조건</a></p></div>'''
    (out / 'index.html').write_text(page + observations + overview + ''.join(sections) + '</html>', encoding='utf-8')
    print(json.dumps({'frames': len(all_frame_rows), 'logo_annotations': len(logos_csv),
                      'web_entities': len(entities_csv), 'web_matches': len(matches_csv)}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('out', type=Path)
    main(parser.parse_args().out)
