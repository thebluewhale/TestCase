# 신규 8영상 — Google Cloud Vision 단독 실험 (2026-10-14)

## 실행 조건

사용자가 Google Cloud Vision 전송을 명시적으로 승인한 뒤 실행했다. Gemini 모델은 호출하지 않았다.
입력은 이 POC의 `benchmarks/*.mp4` 8개다. 수집 DB, 참조 로고, 자체 검출기, OCR, 브랜드 목록,
프롬프트, 파일명 힌트 없이 **프레임 이미지와 기능 설정만** API에 보냈다.

- LOGO_DETECTION + WEB_DETECTION, 각각 `maxResults=100`, `model=builtin/stable`.
- 기존 6영상 실험과 같은 표본 방식: 첫 PTS를 0으로 맞춘 후 각 1초 구간의 첫 디코딩 프레임.
  원본 해상도 JPEG(q=2), 리사이즈/로고 영역 crop 없음. 오디오 미사용.
- **195프레임, 28배치, 기능 단위 390회**, 전 배치 HTTP 200, 프레임 오류 0.
- 로고 annotation 54개, 웹 엔티티 1,449개, 웹 이미지/페이지 결과 6,154개를 원문 보존.
- 점수 임계값으로 걸러내지 않았다. 웹 엔티티 점수는 확률이 아니며 1을 넘는 값도 반환됐다.
- 신규 입력 디렉토리 선택을 위해 기존 `run_vision.py`에 `--video-dir`, `--videos`를 추가했다.
  기본 기존 6영상 설정은 유지하며 재개 시 원본/프레임 해시와 기능/프로젝트/목록을 확인한다.

## 영상별 결과

괄호는 해당 브랜드를 **로고로 반환한 프레임 수**다. 분모는 로고 노출 프레임 수가 아닌 전체
표본 수이므로 재현율로 사용하지 않는다. 한 프레임에 같은 브랜드 annotation이 여러 개일 수 있다.

| 영상 | 표본 | LOGO_DETECTION | 주요 누락·WEB 보완 |
|---|---:|---|---|
| Galaxy_ChocolateWithSTK.mp4 | 11 | Samsung(1) | SKT/T 표현 미검출. SKT 엔티티도 없음. SKT 광고를 명시한 일치 페이지 제목은 3프레임에서 반환 |
| Galaxy_DalgonaWithKT.mp4 | 16 | KT(13), Samsung(1) | 달고나 KT는 0~12초 검출. 13초 희미한 전환 장면에서는 반환되지 않음 |
| Galaxy_FlowerWithSKT.mp4 | 10 | Samsung(1) | SKT/T 심볼 미검출. SKT 엔티티도 없음. SKT 광고를 명시한 페이지 제목은 6프레임에서 반환 |
| Galaxy_HanokWithKT.mp4 | 11 | Samsung(1) | 문 위 KT는 로고 미검출. KT 웹 엔티티는 0~2초 3프레임에서 반환 |
| KIA_EV3InAutumn.mp4 | 27 | Kia(13), Hankook Tire(2) | KIA를 일부 프레임에서 검출. 후면 로고가 보이는 13.012·16.015초 등에도 반환되지 않는 사례가 있음 |
| KIA_WIthFIFA.mp4 | 21 | Kia(4), Adidas(3), FIFA(1), Hardinge, Inc.(1·오탐) | 11초 Lenovo 노트북 표시는 로고/브랜드 엔티티에서 미검출 |
| SKT_AllWayToT1.mp4 | 59 | Samsung(5), T1(3) | 파일명과 달리 화면상 주요 브랜드는 Samsung/T1. SKT 미검출 사례로 분류하지 않음 |
| SKT_WithMegaMGC.mp4 | 40 | SK Telecom(1) | 마지막 39.034초 SK telecom만 로고 검출. MegaMGC는 로고/엔티티 미검출, 메가커피 언급 페이지 제목은 27.023초에서 반환 |

이 표의 실제 노출 여부·오탐 판단은 추출 프레임과 검출 박스를 에이전트가 시각 확인한 결과다.
기존 사람 검수 CSV가 아니며 모든 작은 로고의 정답 위치/노출 구간을 완전하게 라벨링하지는 않았다.

## 요청한 5브랜드 중심 해석

- **SKT**: `SK telecom` 글자 조합은 1프레임 검출(최고 0.700). 초콜릿/꽃의 T 심볼과
  SKT 문구는 로고로 반환되지 않았다. 다른 형태의 참조 로고를 확보할 필요성을 검토할 사례다.
- **KT**: 달고나에서는 13프레임 검출(최고 0.894), 한옥에서는 0. 같은 브랜드라도 표현에 따라
  결과가 달랐다. 재질·대비·배경 등의 개별 원인은 이번 실험으로 분리 검증하지 않았다.
- **MegaMGC**: 간판과 화면 상단 브랜드 표기가 보이지만 로고/브랜드 엔티티 반환 없음.
  일치 페이지의 메가커피 언급은 유용한 관련 단서이나 로고의 위치·브랜드를 검출한 것과 다르다.
- **KIA**: 두 영상에서 각각 13·4프레임 검출(최고 0.971·0.989). 모든 노출 위치를 잡은 것은 아니다.
- **Adidas**: FIFA 영상의 3·8·12초, 3프레임 검출(최고 0.839). 웹 엔티티에는 Adidas가 없었다.
  WEB_DETECTION이 LOGO_DETECTION을 항상 포함하거나 대체하지 않음을 보여준다.

## 추가 관찰

- FIFA 영상 **14.000초의 `FRANCE` 문자**를 `Hardinge, Inc.`로 검출(0.656).
  실제 검출 박스를 확인해 오탐으로 분리했으며 원본 결과에서는 제거하지 않았다.
- EV3 영상의 `Hankook Tire`는 타이어의 실제 Hankook 표기를 확인했다.
- T1은 도입부의 워드마크뿐 아니라 5.004초 양쪽 깃발에서도 검출됐다.
- 웹 엔티티에는 관련 모델명이나 화면에 확인되지 않는 브랜드도 다수 포함된다. 예를 들어 EV3
  광고에 EV2/EV5 등의 이름도 반환되므로 모든 웹 키워드를 광고 내 로고 검출로 계산하지 않는다.
- 표본 내 미검출은 전체 영상 내 부재나 권리 위험 없음의 증거가 아니다. IP 침해 여부나
  risk level을 판정하지 않았다. 결과의 `risk_level=null`은 미판정이다.

## 산출물과 검증

위치: `runs/vision_eight_20261014/`.

- [전체 HTML 리포트](../runs/vision_eight_20261014/index.html): 브랜드 비교, 프레임, 로고 박스,
  점수, 웹 엔티티, 이미지/페이지 링크 및 전체 원문.
- [브랜드별 CSV](../runs/vision_eight_20261014/brand_coverage.csv),
  [근거 JSON](../runs/vision_eight_20261014/brand_coverage.json): 사후 선정 브랜드의 로고/엔티티/
  페이지 제목 반환을 각각 기록. 제목은 명시적인 브랜드명 패턴으로 찾았으며 전체 웹 페이지
  본문을 방문하거나 검증하지 않았다. 반환 URL 자체를 권리자의 공식 페이지로 보증하지 않는다.
- `logos.csv`, `web_entities.csv`, `web_matches.csv`, `frames.csv`: 전체 반환값.
- 각 영상의 `batches/*.response.json`: 수정하지 않은 HTTP 응답 본문.
- `manifest.json`, `execution.json`, `validation.json`: 입력·프레임 SHA-256, 시각, 설정,
  요청 상태, 195프레임 누락/오류 없음 검증.
- [검출 위치 점검 그림](../runs/vision_eight_20261014/logo_detail_checks.jpg): FRANCE 오탐,
  실제 KIA/Hankook/T1 표기 대조.

원본 8개와 프레임 195개의 해시를 대조했다. 선택 입력 경로·API opt-in 관련 기존 독립성 테스트
3개를 통과했다. 원래 6영상 결과와 수집 DB는 변경하지 않았다. 운영 코드/배포 변경 없음.
