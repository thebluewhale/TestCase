"""기존 S0 + S1 실행 및 등장 구간을 이용한 장면별 객체 표 생성. 서비스 코드 변경 없음."""
import csv
import hashlib
import json
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from review_anomaly_v2.cli import _summary
from review_anomaly_v2.config import load_config
from review_anomaly_v2.preprocess import PreprocessResult, preprocess
from review_anomaly_v2.scene import build_scene_index
from review_anomaly_v2.schemas import MediaAsset, Shot
from review_anomaly_v2.settings import Settings
from review_anomaly_v2.vlm import build_primary_client
from review_anomaly_v2.vlm.media import video_part

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
VIDEOS = ROOT / 'benchmarks/manual/galaxy/videos'
cfg = load_config()
settings = Settings(_env_file=ROOT.parents[1] / '.env')
shutil.copyfile(ROOT / 'config/default.yaml', OUT / 'config.yaml')
(OUT / 'run_meta.json').write_text(json.dumps({
    'model': settings.vlm_model, 'region': settings.vertex_region,
    'stages': ['S0 preprocess', 'S1 scene index'], 'parallel_videos': 2,
    'object_mapping': 'SceneManifest.entities.appearances.shot_id',
    'automatic_merging': False,
    'limitations': '영상 단위 VLM 객체 목록과 등장 구간의 교집합. 프레임별 박스 검출/추적/이상 판정 제외.',
}, ensure_ascii=False, indent=2))


def run(path):
    result_path = OUT / (path.stem + '.json')
    if result_path.exists():
        stored = json.loads(result_path.read_text())
        if stored.get('status') == 'ok':
            return stored
    started = time.perf_counter()
    result = {'file': path.name, 'status': 'started', 'stages_sec': {}}
    try:
        print(json.dumps({'file': path.name, 'stage': 'preprocess'}, ensure_ascii=False), flush=True)
        stage = time.perf_counter()
        saved_pre = OUT / 'preprocess' / (path.stem + '.json')
        if saved_pre.exists():
            saved = json.loads(saved_pre.read_text())
            with path.open('rb') as source:
                assert hashlib.file_digest(source, 'sha256').hexdigest() == saved['asset']['sha256']
            pre = PreprocessResult(asset=MediaAsset.model_validate(saved['asset']), quality=[],
                                   shots=[Shot.model_validate(s) for s in saved['shots']])
            result['preprocess_reused'] = True
            result['preprocess'] = saved
        else:
            pre = preprocess(path, cfg)
            result['preprocess_reused'] = False
            result['preprocess'] = _summary(pre, time.perf_counter() - stage)
        result['stages_sec']['preprocess'] = time.perf_counter() - stage
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2))
        print(json.dumps({'file': path.name, 'stage': 'video_prepare', 'shots': len(pre.shots)}, ensure_ascii=False), flush=True)
        stage = time.perf_counter()
        media = video_part(path, pre.asset.sha256, pre.asset.duration_sec, cfg.vlm, OUT / 'work' / path.stem)
        result['stages_sec']['video_prepare'] = time.perf_counter() - stage
        client = build_primary_client(settings, cfg.vlm, ROOT / 'outputs/vlm_cache')
        print(json.dumps({'file': path.name, 'stage': 'scene_index'}, ensure_ascii=False), flush=True)
        stage = time.perf_counter()
        scene = build_scene_index(pre, media, client, cfg.vlm)
        result['stages_sec']['scene_index'] = time.perf_counter() - stage
        result['manifest'] = scene.manifest.model_dump(mode='json')
        result['notes'] = scene.notes
        result['cache_hits'] = client.hits
        result['cache_misses'] = client.misses
        rows = []
        for shot in pre.shots:
            entities = [e for e in scene.manifest.entities if any(a.shot_id == shot.shot_id for a in e.appearances)]
            texts = [e.name for e in entities if any(r.value in ('text', 'logo') for r in e.roles)]
            objects = [e.name for e in entities if not any(r.value in ('text', 'logo') for r in e.roles)]
            rows.append({'file': path.name, 'scene': shot.shot_id + 1,
                         'start_sec': shot.time_range.start_sec, 'end_sec': shot.time_range.end_sec,
                         'objects': objects, 'text_logo': texts,
                         'short_shot_review': shot.short_shot_review.model_dump(mode='json') if shot.short_shot_review else None})
        result['rows'] = rows
        result['unmapped_entities'] = [e.name for e in scene.manifest.entities if not e.appearances]
        result['status'] = 'ok'
    except Exception as exc:
        result['status'] = 'error'
        result['error'] = f'{type(exc).__name__}: {exc}'
    result['elapsed_sec'] = time.perf_counter() - started
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps({'file': path.name, 'status': result['status'], 'elapsed_sec': round(result['elapsed_sec'], 2), 'error': result.get('error')}, ensure_ascii=False), flush=True)
    return result


if __name__ == '__main__':
    paths = sorted(VIDEOS.glob('*.mp4'))
    assert len(paths) == 9, f'Expected 9 videos, got {len(paths)}'
    results = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(run, path) for path in paths]):
            results.append(future.result())
    results.sort(key=lambda r: r['file'])
    (OUT / 'summary.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
    with (OUT / 'scenes.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['file', 'scene', 'start_sec', 'end_sec', 'objects', 'text_logo', 'short_shot_review'])
        writer.writeheader()
        for result in results:
            for row in result.get('rows', []):
                writer.writerow({**row, 'objects': ' / '.join(row['objects']), 'text_logo': ' / '.join(row['text_logo']),
                                 'short_shot_review': json.dumps(row['short_shot_review'], ensure_ascii=False)})
    print(json.dumps({'completed': sum(r['status'] == 'ok' for r in results), 'total': len(results), 'output': str(OUT)}, ensure_ascii=False), flush=True)
