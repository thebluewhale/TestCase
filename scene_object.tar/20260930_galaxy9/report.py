"""완료 결과 검증 및 장면별 HTML 표 생성."""
import csv
import html
import json
from pathlib import Path

out = Path(__file__).resolve().parent
results = json.loads((out / 'summary.json').read_text())
assert len(results) == 9 and all(r['status'] == 'ok' for r in results)
parts = ['''<!doctype html><html lang="ko"><meta charset="utf-8">
<title>Galaxy 9개 영상 — 장면 분할 및 객체 추출</title>
<style>body{font-family:system-ui,sans-serif;margin:32px;line-height:1.6;color:#18212b}
table{border-collapse:collapse;width:100%;margin-bottom:32px}th,td{border:1px solid #cbd5e1;padding:8px;text-align:left}
th{background:#eaf0f7}td:first-child{white-space:nowrap}h2{font-size:18px}small{color:#475569}</style>
<h1>9개 영상의 장면 분할 및 주요 객체 추출</h1>
<p>현재 S0 장면 분할 + S1 장면 인덱스 결과. 시간은 원본 시작 기준 초입니다.
객체의 추정 등장 구간과 장면이 겹치면 표에 포함합니다. 구간 내내 등장한다는 뜻은 아닙니다.
객체 이름·등장 시각은 모델 출력이며 육안 정답 검증 전입니다. 자동 장면 병합은 적용하지 않았습니다.</p>''']
total = 0
for result in results:
    name = result['file']
    rows = result['rows']
    assert len(rows) == len(result['preprocess']['shots'])
    assert rows[0]['start_sec'] == 0
    assert rows[-1]['end_sec'] == result['preprocess']['asset']['duration_sec']
    assert all(a['end_sec'] == b['start_sec'] for a, b in zip(rows, rows[1:]))
    total += len(rows)
    parts.append(f'<h2>{html.escape(name)}</h2><table><tr><th>장면</th><th>구간(초)</th><th>물체·배경</th><th>문구·로고</th><th>짧은 장면 재검증</th></tr>')
    for row in rows:
        review = row['short_shot_review']
        cells = [str(row['scene']), f"{row['start_sec']:.3f}–{row['end_sec']:.3f}",
                 ', '.join(row['objects']) or '추출 없음', ', '.join(row['text_logo']) or '추출 없음',
                 review['assessment'] + ': ' + review['reason'] if review else '대상 아님']
        parts.append('<tr>' + ''.join('<td>' + html.escape(c) + '</td>' for c in cells) + '</tr>')
    parts.append('</table>')
assert total == 38
parts.append('</html>')
(out / 'report.html').write_text('\n'.join(parts), encoding='utf-8')
with (out / 'scene_splits.csv').open(encoding='utf-8-sig', newline='') as f:
    old_rows = list(csv.DictReader(f))
for row in old_rows:
    row['object_status'] = 'completed_see_scenes.csv'
with (out / 'scene_splits.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(old_rows[0]))
    writer.writeheader()
    writer.writerows(old_rows)
print(json.dumps({'videos':len(results), 'scenes':total, 'cache_hits':sum(r['cache_hits'] for r in results),
                  'cache_misses':sum(r['cache_misses'] for r in results),
                  'unmapped_entities':sum(len(r['unmapped_entities']) for r in results),
                  'notes':sum(len(r['notes']) for r in results)}, ensure_ascii=False))
